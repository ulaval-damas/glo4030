import torch
import torch.nn as nn


class MyDropout(nn.Module):

    def __init__(self, drop_probability):
        self.drop_probability = drop_probability


    def forward(self, x):
        pass

