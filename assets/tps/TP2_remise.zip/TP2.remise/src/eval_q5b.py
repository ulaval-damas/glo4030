import sys
import torch
import pickle

if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise RuntimeError('You must provide the path to the dataset as an argument')

    dataset_path = sys.argv[1]
    test_examples = pickle.load(open(dataset_path, 'rb')) # Loads a pickle file

    ### TODO Your code here

    # Load your pre-trained model in evaluation mode

    # Your model should accept an Article object and predict its author (textual form of the author like "richard-martineau")
    # Don't worry, we know that the Article object contains the author.
    # It does not mean that the Article object that we will feed to your model will contain this attribute.
    # Just in case you wanted to return the author systematically... :)

    # We want here to have the accuracy on the test set


    # Test on the dataset


