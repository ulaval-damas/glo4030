import sys
import torch
import torchvision
from torchvision.datasets import ImageFolder


if __name__ == '__main__':
    if len(sys.argv) < 2:
        raise RuntimeError('You must provide the path to the dataset as an argument')

    dataset_path = sys.argv[1]
    dataset = ImageFolder(dataset_path)

    ### TODO Your code here

    # Load your pre-trained model in evaluation mode


    # Test on the dataset


