import torch
import torch.nn as nn
import torch.nn.functional as F

from src.deeplib.datasets import load_mnist
from src.deeplib.training import train
from src.deeplib.testing import test


class MnistNet(nn.Module):

    def __init__(self):
        super(MnistNet, self).__init__()
        # Créer l'architecture du réseau
        # self.fc1 = nn.Linear(, ))
        pass

    def forward(self, x):
        x = x.view(-1, 28*28)
        # À compléter

        return x

if __name__ == '__main__':
    mnist_train, mnist_test = load_mnist(path='./mnist')

    model = MnistNet()
    model.cuda()

    # Trouvez de bons hyperparamètres pour obtenir 100% de précision sur le jeu d'entraînement
    use_gpu = True
    n_epoch = 0
    batch_size = 0
    learning_rate = 0

    history = train(model, mnist_train, n_epoch, batch_size, learning_rate, use_gpu=use_gpu)

    history.display()

    test_acc, test_loss = test(model, mnist_test, batch_size, use_gpu=use_gpu)
    print('Test:\n\tLoss: {}\n\tAccuracy: {}'.format(test_loss, test_acc))
