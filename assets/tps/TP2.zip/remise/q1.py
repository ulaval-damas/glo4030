import torch

def mnist_dataset(train_split_percent=0.8, padding=0, rotation=0):
    return None, None, None
