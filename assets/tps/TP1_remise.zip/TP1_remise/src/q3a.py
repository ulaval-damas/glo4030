from torchvision.transforms import ToTensor

from src.deeplib.data import train_valid_loaders
from src.deeplib.datasets import load_mnist
from src.q2 import MnistNet


"""
Coder la fonction calculate_dead_neurons

La fonction doit prendre en entrée un modèle, un loader et un nombre de batch et retourner un dictionnaire
contenant la moyenne sur toutes les batchs du pourcentage de neurones morts pour chaque couche ainsi que la moyenne globale.

N'entraînez pas le réseau. Faites seulement une forward pass et une backward pass pour calculer le gradient sans
mettre à jour les poids du réseau.

Un neurone est considéré mort si son gradient est nul après la backward pass, donc n'est jamais activé sur un jeu de donnée.

"""


def calculate_dead_neurons(net, loader, n_batch, use_gpu=True):
    pass

if __name__ == '__main__':
    model = MnistNet()
    model.cuda()

    mnist_train, _ = load_mnist(path='./mnist')
    mnist_train.transform = ToTensor()
    train_loader, _ = train_valid_loaders(mnist_train, batch_size=32)

    stats = calculate_dead_neurons(model, train_loader, 5)
    print(stats)
