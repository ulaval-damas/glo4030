import torch

from src.deeplib.data import train_valid_loaders
from src.deeplib.datasets import load_mnist
from src.deeplib.training import train
from src.q3a import calculate_dead_neurons
from src.deeplib.testing import test
from src.q2 import MnistNet


if __name__ == '__main__':

    # Vous pouvez changer les hyperparamètres.
    # Par contre, assurez-vous d'utiliser les mêmes pour toutes les expérimentations
    use_gpu = True
    n_epoch = 10
    batch_size = 32
    learning_rate = 0.01

    mnist_train, mnist_test = load_mnist(path='./mnist')
    mnist_train.transform = ToTensor()
    train_loader, _ = train_valid_loaders(mnist_train, batch_size)

    model = MnistNet()
    model.cuda()

    # Initialisez les paramètres du modèle ici.

    print(calculate_dead_neurons(model, train_loader, 5))
    train(model, mnist_train, n_epoch=n_epoch, batch_size=batch_size, learning_rate=learning_rate, use_gpu=use_gpu)
    test_acc, test_loss = test(model, mnist_test, batch_size, use_gpu=use_gpu)
    print('Test:\n\tLoss: {}\n\tAccuracy: {}'.format(test_loss, test_acc))
