import matplotlib.pyplot as plt
import torch.nn as nn

from src.deeplib.datasets import load_mnist
from src.deeplib.training import train


class Net(nn.Module):

    def __init__(self):
        super(Net, self).__init__()
        # Créer l'architecture du réseau
        # self.fc1 = nn.Linear(, ))
        pass

    def forward(self, x):
        x = x.view(-1, 28*28)
        # À compléter
        pass


def visualize_weights(model):
    # À compléter
    pass


if __name__ == '__main__':

    model = Net()
    model = model.cuda()
    mnist_train, _ = load_mnist(path='./mnist', download=True)
    train(model, dataset=mnist_train, batch_size=32, learning_rate=0.01, n_epoch=10, use_gpu=True)
    visualize_weights(model)
